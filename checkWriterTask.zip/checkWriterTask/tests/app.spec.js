describe('The test filter', function () {
  'use strict'; 

  var $filter;

  beforeEach(function () {
    module('app');

    inject(function (_$filter_) {
      $filter = _$filter_;
    });
  });

  it('Should convert into word', function () {
    // Arrange.
    var foo = '123', result;

    // Act.
    result = $filter('wordsFilter')(foo);

    // Assert.
    expect(result).toEqual('One Hundred Twenty Three dollars only ');
  });
  it('Should convert into word', function () {
    // Arrange.
    var foo = '257483.00', result;

    // Act.
    result = $filter('wordsFilter')(foo);

    // Assert.
    expect(result).toEqual('Two hundred fifty seven thousand four hundred eighty three dollars only');
  });
    it('Should convert into word', function () {
    // Arrange.
    var foo = '466437.78', result;

    // Act.
    result = $filter('wordsFilter')(foo);

    // Assert.
    expect(result).toEqual('Four Lakhs Sixty Six Thousand Four Hundred Thirty Seven dollars and 78/100');
  });
   it('Should convert into word', function () {
    // Arrange.
    var foo = '-22', result;

    // Act.
    result = $filter('wordsFilter')(foo);

    // Assert.
    expect(result).toEqual('Please Enter Numbers only');
  });
  
  
    it('Should convert into word', function () {
    // Arrange.
    var foo = '999999999', result;

    // Act.
    result = $filter('words')(foo);

    // Assert.
    expect(result).toEqual('Nine hundred ninety nine million nine hundred ninety nine thousand nine hundred ninety nine dollars only');
  });

});