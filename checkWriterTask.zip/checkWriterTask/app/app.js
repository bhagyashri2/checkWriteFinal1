var app= angular.module('myapp',[]);
		app.controller('puzzleController',function($scope,$http){
			 $scope.example = {
       
        word:  /^[0-9]+\.?[0-9]*$/
      };
			
		});