# checkWriteFinal1

 Give a currency value input the English equivalent as written on a check:
 
    Sample:   Input: 125.75      Output: One hundred twenty five dollars and 75/100
              Input: 95.00       Output: Ninety five dollars only
              Input: 69          Output: Sixty nine dollars only
			  
	Note1 : 	Input must be numbers or decimals only	  
	Note2 : 	Input must contain numbers only	  		  