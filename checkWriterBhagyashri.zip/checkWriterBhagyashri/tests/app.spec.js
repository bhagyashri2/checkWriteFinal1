describe('The test filter', function () {
  'use strict'; 

  var $filter;

  beforeEach(function () {
    module('myapp');

    inject(function (_$filter_) {
      $filter = _$filter_;
    });
  });

  it('Should convert into word', function () {
    // Arrange.
    var name = '123', result;

    // Act.
    result = $filter('wordsFilter')(name);

    // Assert.
    expect(result).toEqual('One hundred twenty three dollars only');
  });
  it('Should convert into word', function () {
    // Arrange.
    var name = '257483.00', result;

    // Act.
    result = $filter('wordsFilter')(name);

    // Assert.
    expect(result).toEqual('Two hundred fifty seven thousand four hundred eighty three dollars only');
  });
    it('Should convert into word', function () {
    // Arrange.
    var name = '466437.78', result;

    // Act.
    result = $filter('wordsFilter')(name);

    // Assert.
    expect(result).toEqual('Four hundred sixty six thousand four hundred thirty seven dollars  and 78/100');
  });   
       
  it('Should convert into word', function () {
    // Arrange.
    var name = '99999999999999999999999999999', result;

    // Act.
    result = $filter('wordsFilter')(name);

    // Assert.
    expect(result).toEqual('Entered number is too big');
  });
  
});