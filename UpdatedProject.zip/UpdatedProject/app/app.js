var app= angular.module('myapp',[]);
		
		app.controller('puzzleController', ['$scope', function($scope) {
				
			$scope.regex = /^[0-9]+\.?[0-9]*$/;
		
		
    }]);