/* Filter For conversion of digits to words */
	/* Starts Here */  
	app.filter('wordsFilter', function() 
	{
		var completeStr = "";
		/* To check whether integer is entered */ 
		  function isInteger(x) {
				return x % 1 === 0;
			}
		  return function(value) {
			if (value){	     
			var stringValue= angular.copy(value);  // If integer value appeared then store value 
			var ys = value.indexOf('.');			//split value with help of indexof
			
			var Splitdata="";
			if (ys != -1){								
				Splitdata=value.substr(ys+1,value.length);	 // check if value contains decimal number
			}
			
		var stringAfterDecimal = Splitdata? toWords(Splitdata,'afterDecimal'):'';  // Send number to function for conversion
			var stringBeforeDecimal = toWords(stringValue,null)
			if(stringAfterDecimal.indexOf('and')!= -1){
				stringBeforeDecimal =stringBeforeDecimal.replace("only",' ');
				
			}
			completeStr = stringBeforeDecimal.concat(stringAfterDecimal);
			return completeStr.charAt(0).toUpperCase()+ completeStr.slice(1) ;
			
			}    
			//return value;
		  };

	});
		var th = ['','thousand','million', 'billion','trillion'];
		var dg = ['zero','one','two','three','four', 'five','six','seven','eight','nine']; 
		var tn = ['ten','eleven','twelve','thirteen', 'fourteen','fifteen','sixteen', 'seventeen','eighteen','nineteen'];
		var tw = ['twenty','thirty','forty','fifty', 'sixty','seventy','eighty','ninety']; 

		var tempString="";
		/* Conversion of number to words function */
		/* -------------- Starts here -------------------- */
		function toWords(s,type)
		{   
		if(type=='afterDecimal'){
		 if(s %10==00){
		 return '';
		 }else{
			 return  'and '+s+'/100';	  
		 }
		}else if(s == 0){
			return 'Zero dollars only';
		}
		else{
			s = s.toString(); 
			s = s.replace(/[\, ]/g,''); 
			var x = s.indexOf('.'); 
			if (x == -1) x = s.length; 
			if (x > 9) return 'Entered number is too big'; 
			var n = s.split(''); 
			var str = ''; 
			var sk = 0; 
			for (var i=0; i < x; i++) 
			{
				if ((x-i)%3==2)    /* Check number is of how many digits */ 
				{
					if (n[i] == '1') 
					{
						str += tn[Number(n[i+1])] + ' '; 
						i++; 
						sk=1;
					}
					else if (n[i]!=0) 
					{
						str += tw[n[i]-2] + ' ';
						sk=1;
					}
				}
				else if (n[i]!=0)   /* Converts for string hundred */
				{
					str += dg[n[i]] +' '; 
					if ((x-i)%3==0) str += 'hundred ';
					sk=1;
				}
				if ((x-i)%3==1)
				{
					if (sk) str += th[(x-i-1)/3] + ' ';
					sk=0;
				}
			}
			
			  var y = s.length; 
			  str += 'dollars only'; 	
			  return str.replace(/\s+/g,' ');
			
			}
		}
		window.toWords = toWords;
	/* --------------End here ------------------------ */