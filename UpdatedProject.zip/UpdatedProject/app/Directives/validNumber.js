/* ------------- Validation of input Code Starts Here  --------------*/
	app.directive('validNumber', function() {
		  return {
			require: '?ngModel',
			link: function(scope, element, attrs, ngModelCtrl) {
			  if(!ngModelCtrl) {
				return; 
			  }

			  ngModelCtrl.$parsers.push(function(val) {
				if (angular.isUndefined(val)) {
					var val = '';
				}
				
				var clean = val.replace(/[^-0-9\.]/g, '');
				var negativeCheck = clean.split('-');
				var decimalCheck = clean.split('.');
				if(!angular.isUndefined(negativeCheck[1])) {
					negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
					clean =negativeCheck[0] + '-' + negativeCheck[1];
					if(negativeCheck[0].length > 0) {
						clean =negativeCheck[0];
						return clean;
					}                
				}              
				if(!angular.isUndefined(decimalCheck[1])) {
					decimalCheck[1] = decimalCheck[1].slice(0,5);
					clean =decimalCheck[0] + '.' + decimalCheck[1];
				}

				if (val !== clean) {
				  ngModelCtrl.$setViewValue(clean);
				  ngModelCtrl.$render();
				}
				return clean;
			  });

			  element.bind('keypress', function(event) {
				if(event.keyCode === 32) {
				  event.preventDefault();
				}
			  });
			  
			}
		  };
		});
		app.directive('decimalPlaces',function(){
    return {
        link:function(scope,ele,attrs){
            ele.bind('keypress',function(e){
                var newVal=$(this).val()+(e.charCode!==0?String.fromCharCode(e.charCode):'');
                if($(this).val().search(/(.*)\.[0-9][0-9]/)===0 && newVal.length>$(this).val().length){
                    e.preventDefault();
                }
            });
        }
    };
});
app.directive('config', function() {
  return {
    restrict: 'E',
    scope: {
      data: '='
    },
		template: '<form name="myForm">' +
		'<input type="text" name="input" ng-model="name" ng-pattern="regex" id="regex" required ng-trim="false" step="0.01">'
      +
      
      '</form>',
    controller: 'puzzleController',
  };
});
		
	/* ---------------- End Here ----------------------*/